# -*- coding: utf-8 -*-
"""
Created on Fri Jan 12 17:19:35 2024

@author: HP
"""

from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
from datetime import datetime

app = Flask(__name__)

# Create an empty DataFrame to store reservations
columns = ['Name', 'Check-in Date', 'Check-out Date', 'Room Type']
reservations_df = pd.DataFrame(columns=columns)

@app.route('/')
def index():
    return render_template('index.html', reservations=reservations_df.to_html())

@app.route('/book', methods=['POST'])
def book():
    if request.method == 'POST':
        name = request.form['name']
        checkin_date = request.form['checkin_date']
        checkout_date = request.form['checkout_date']
        room_type = request.form['room_type']

        reservations_df.loc[len(reservations_df)] = [name, checkin_date, checkout_date, room_type]

        # Save the reservations to an Excel file
        reservations_df.to_excel('reservations.xlsx', index=False)

        return redirect(url_for('index'))

@app.route('/check')
def check():
    return render_template('check.html', reservations=reservations_df.to_html())

if __name__ == '__main__':
    app.run(debug=True)
